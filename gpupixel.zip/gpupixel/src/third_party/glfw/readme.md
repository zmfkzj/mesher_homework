current glfw version: 3.3.8
glfw version 3.3.9 has bug, can not work in Parallel.