//
//  AppDelegate.h
//  SimpleVideoFilter
//
//  Created by gezhaoyou on 2021/8/25.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

