//
//  ViewController.h
//  SimpleVideoFilter
//
//  Created by gezhaoyou on 2021/8/25.
//

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController


@end

