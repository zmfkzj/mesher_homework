//
//  MGLicenseCommon.h
//  MGMobileSDKAuth
//
//  Created by 张英堂 on 2017/1/10.
//  Copyright © 2017年 megvii. All rights reserved.
//

#ifndef MGLicenseCommon_h
#define MGLicenseCommon_h

static NSString* MGLicenseURL_CN =
    @"https://api-cn.faceplusplus.com/sdk/v3/auth";
static NSString* MGLicenseURL_US =
    @"https://api-us.faceplusplus.com/sdk/v3/auth";

#endif /* MGLicenseCommon_h */
